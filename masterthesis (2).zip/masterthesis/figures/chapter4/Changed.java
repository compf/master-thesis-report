public class Library {
    public boolean someLibraryMethod() {
        System.out.println(numProp.getSign());
        System.out.println(numProp.getMantissa());
        System.out.println(numProp.getExponent());
        return true;
    }
     private NumProp numProp;
}
