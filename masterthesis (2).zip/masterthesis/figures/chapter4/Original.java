public class Library {
    public boolean someLibraryMethod() {
       System.out.println(sign);
       System.out.println(mantissa);
       System.out.println(exponent);
        return true;
    }
    private boolean sign;
    private double mantissa;
    private int exponent;
}
