/**
 * Calculates the square root
 * @param  number a positive number
 * @return the positive square root of the number
 */
double calculateSquareRoot(double number){
    // ...
}

/**
 * Returns always a positive number
 * @param  number any number
 * @return a positive number
 */
double absoluteValue(double number){
    // ...
}