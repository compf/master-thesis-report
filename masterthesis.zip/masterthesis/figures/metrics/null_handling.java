/**
 * Assign all field values of the target to the source
 * @param target the target object, may not be null
 * @param source the source object
 */
void assign(Object target,Object source){

}